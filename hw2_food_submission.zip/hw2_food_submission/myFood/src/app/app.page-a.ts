import { Component } from '@angular/core';
@Component({
  template: `This is Home A.`
})
export class PageAComponent { }
