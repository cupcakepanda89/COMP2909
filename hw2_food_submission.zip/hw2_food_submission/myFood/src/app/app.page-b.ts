import { Component } from '@angular/core';
@Component({
  template: `This is About page.
  
  
  `
})
export class PageBComponent { }
