export class Food {
  id: number;
  name: string;
  mfg: string;
  pkg: string;
  qty:number;
}
