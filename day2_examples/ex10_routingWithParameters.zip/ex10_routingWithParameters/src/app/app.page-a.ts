import { Component } from '@angular/core';
@Component({
    templateUrl:'./pageA.html'
})
export class PageAComponent { }
