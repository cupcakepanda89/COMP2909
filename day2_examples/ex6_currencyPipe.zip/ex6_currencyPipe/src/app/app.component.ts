import { Component } from '@angular/core';

@Component({
    selector: 'app-root',
    template: ` 
	    {{price | currency:'USD':true}}<br/>
	    `,
})
export class AppComponent {
    price: number = 23.23333;
    constructor() {

    }
}
