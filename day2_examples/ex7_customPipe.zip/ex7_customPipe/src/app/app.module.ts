import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppComponent } from './app.component';
import { FahrenheitPipe } from './app.fahrenheitPipe';

@NgModule({
  declarations: [
    AppComponent,
    FahrenheitPipe
  ],
  imports: [
    BrowserModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
