import { Component } from '@angular/core';
@Component({
    template: `This is page A.`
})
export class PageAComponent { }
